class BookingsController < ApplicationController

   def index
    @bookings = Booking.all
  end

  def show
    @booking=Booking.find(params[:id])
  end

  def new
     @booking = Booking.new
  end

  

  def create
    @booking = Booking.new(booking_params)
    @booking.user_id=current_user.id
    respond_to do |format|
      if @booking.save
        format.html { redirect_to booking_path(@booking), notice: "booking was successfully created." }
      else
        format.html { render :new, status: :unprocessable_entity }
      end 
    end    
  end 

  
  
  private
  
  

  def booking_params
    params.require(:booking).permit(:start_date, :end_date, :status, :price)
  end
end



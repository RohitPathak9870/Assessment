class CustomerDashboardsController < ApplicationController
	def create

		@user = Booking.create(user_params)

		if @booking.save
			redirect_to 'show'
		else
			redirect_to 'create'
		end
	end

	private 

	def user_params
		user_params.require(:user).permit(:start_date, :end_date, :status, :price)
	end
end

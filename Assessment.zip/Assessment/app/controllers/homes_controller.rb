class HomesController < ApplicationController
	
end

class Role < ApplicationRecord
end
